module.exports = () => {
    console.log('Say 123456789123456789 123456 abc Hello from mahesh kumar Layer 2 Dependency!');
};
