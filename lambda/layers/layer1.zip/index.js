module.exports = () => {
    console.log('Say 12345678910123456789 123456 abc Hello from mahesh kumar Layer 1  added Dependency!');
};
