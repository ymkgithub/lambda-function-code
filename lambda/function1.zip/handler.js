exports.handler = async (event) => {
    return {
        statusCode: 200,
        body: JSON.stringify('Say Hi 123456789 and Hello from mahesh kumar to Function 1!'),
    };
};
